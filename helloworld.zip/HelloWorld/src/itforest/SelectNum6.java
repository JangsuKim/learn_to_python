package itforest;

import javax.swing.JOptionPane;

public class SelectNum6 {
	static int num6[] = new int[6];

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		int tmp;
		int idx01, idx02, idx03, idx04, idx05;
		String msg;

		//ランダムの番号６個作成及び重複検査
		for (idx01 = 0; idx01 < num6.length; idx01++) {			//６回繰り返す
			num6[idx01] = (int)(Math.random()*43 + 1);			//１～４３の間の数字を作成
			if (num6[idx01]!=0) {								//２個目から重複検査をスタート
				for(idx02 = 0; idx02<idx01; idx02++) {			//他の数字と比較
					if(num6[idx01]==num6[idx02]) {
						idx01 = idx01 - 1;
					}
				}
			}
		}

		for (idx03 = 0; idx03 < num6.length-1; idx03++) {
			for (idx04 = idx03+1; idx04 < num6.length; idx04++) {
				if (num6[idx03] > num6[idx04]) {
					tmp = num6[idx03];
					num6[idx03] = num6[idx04];
					num6[idx04] = tmp;
				}
			}
		}
		msg = "행운의 번호는 ";
		for (idx05 = 0; idx05 < num6.length; idx05++) {
			msg = msg + "[" + num6[idx05] + "] ";
		}
		msg = msg + "입니다!\n행운을 빕니다!";
		System.out.println(msg);
		JOptionPane.showMessageDialog(null, msg);
	}

}
