package itforest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class HelloWorld {
	static int num[] = {-5, 2, 4, 0, 11, -3, -6, 10, 20, 1};
	static int STATIC_ZERO = 0;
	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ

		String state = "";
		int absolute = 0;
		double ttl = 0;
		double avr = 0;

		Calendar cal = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");

		for (int idx01=0; idx01<num.length; idx01++) {
			//정수, 실수 구분
			if (num[idx01] < STATIC_ZERO)	 {
				state = "負";
			} else {
				state = "正";
			}
			//합계 계산
			ttl = ttl + num[idx01];
			//절대값
			absolute = Math.abs(num[idx01]);
			//오늘 날짜 설정
			cal.setTime(new Date());
			//오늘 날짜에 num[idx01]값 반영
			cal.add(Calendar.DATE, num[idx01]);

			System.out.println("=======================================");
			System.out.println(num[idx01]+"は"+state+"の数です");
			System.out.println(num[idx01]+"の絶対値は"+absolute+"です");
			System.out.println("今日から"+num[idx01]+"経った日は"+df.format(cal.getTime())+"\n");
		}
		//num[idx01] 합계의 평균값 계산
		avr = ttl / num.length;
		System.out.println("=======================================");
		System.out.println("全項目の平均は"+avr);
		System.out.println("全項目の合計は"+ttl);
		System.out.println();
	}
}
